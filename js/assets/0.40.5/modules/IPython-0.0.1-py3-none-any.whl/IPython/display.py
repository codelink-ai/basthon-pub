import basthon
from binascii import b2a_base64


__all__ = ["display", "clear_output", "Image", "display_image", "HTML", "IFrame", "SVG"]


display = basthon.display


def clear_output(*args, **kwargs):
    """ Fake function for Basthon. """
    pass


class Image:
    """ Display an image from raw data. """
    def __init__(self, data, format='png'):
        if format.lower() != 'png':
            raise ValueError("Only PNG format is supported.")
        self.format = format
        self.data = data

    def _repr_png_(self):
        return b2a_base64(self.data).decode('ascii')


def display_image(img):
    """ Displaying image from numpy array  """
    from matplotlib import image
    import base64
    import io

    def _repr_png_():
        raw = io.BytesIO()
        image.imsave(raw, img, format="png", cmap='gray')
        raw.seek(0)
        return base64.b64encode(raw.read()).decode()

    dummy = type('image', (), {})()
    dummy._repr_png_ = _repr_png_
    display(dummy)


class HTML:
    """ Sending html string to IPython notebook. """
    def __init__(self, html):
        self._html = html

    def _repr_html_(self):
        return self._html


class SVG:
    """ Sending svg string to IPython notebook. """
    def __init__(self, svg):
        self._svg = svg

    def _repr_svg_(self):
        return self._svg


class IFrame(HTML):
    """ Embed an iframe in IPython notebook. """
    def __init__(self, src, width, height):
        super().__init__(f'<iframe src="{src}" allowfullscreen="" width="{width}" height="{height}" frameborder="0"></iframe>')
